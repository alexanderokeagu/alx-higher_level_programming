-- Inserts a new row into the table first_table.
INSERT INTO `first_table` (`id`, `name`) VALUES (89, "Best School")
