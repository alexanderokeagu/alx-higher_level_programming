-- Lists all rows of the table first_table.
SELECT * FROM `first_table`;
