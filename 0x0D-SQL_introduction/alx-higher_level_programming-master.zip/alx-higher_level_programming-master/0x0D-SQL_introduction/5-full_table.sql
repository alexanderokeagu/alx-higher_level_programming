-- Prints the full description of the table first_table.
SHOW CREATE TABLE `first_table`;
