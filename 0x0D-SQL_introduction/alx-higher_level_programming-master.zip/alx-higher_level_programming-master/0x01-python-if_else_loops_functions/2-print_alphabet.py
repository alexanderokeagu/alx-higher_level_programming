#!/usr/bin/python3
for a in range(ord('a'), ord('z') + 1):
    print("{:c}".format(a), end='')
