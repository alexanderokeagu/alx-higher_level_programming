#!/usr/bin/python3
str = "Holberton School"
print(str+str+str+'\n'+str[:9])
