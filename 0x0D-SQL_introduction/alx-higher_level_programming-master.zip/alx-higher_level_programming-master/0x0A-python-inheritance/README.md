# 0x0A. Python - Inheritance
