0x0C-python-almost_a_circle
